# cropping
cropping is a tool for creating image patches that can be used for machine learning with Haar or LBP based classifiers
